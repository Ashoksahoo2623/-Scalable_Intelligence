$('.items .abc').on('click', function () {
  var $this = $(this),
    $bc = $('<div class="item"></div>');

  $this.parents('li').each(function (n, li) {
    var $a = $(li).children('a').clone();
    $bc.prepend(' / ', $a);
  });
  $('.breadcrumb1').html($bc.prepend('<a href="landing-page.html"><img src="app-assets/images/home.png" alt="" style="width: 16px;position: relative;"></a>'));
  return false;
})

// $(".items .abc").click(function (e) {
//   e.preventDefault();
//   $(".menu-content li").removeClass("open");
//   $(this).closest('.extra-menu').addClass('open');
//   $(this).closest('li').addClass('open');
// });