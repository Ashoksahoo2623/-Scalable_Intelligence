(function (window, undefined) {
  'use strict';

  /*
  NOTE:
  ------
  PLACE HERE YOUR OWN JAVASCRIPT CODE IF NEEDED
  WE WILL RELEASE FUTURE UPDATES SO IN ORDER TO NOT OVERWRITE YOUR JAVASCRIPT CODE PLEASE CONSIDER WRITING YOUR SCRIPT HERE.  */

})(window);

// -----------------------------
// Loader js start
// -----------------------------
document.onreadystatechange = function () {
  if (document.readyState !== "complete") {
    document.querySelector(
      "body").style.visibility = "hidden";
    document.querySelector(
      "#element").style.visibility = "visible";
  } else {
    document.querySelector(
      "#element").style.display = "none";
    document.querySelector(
      "body").style.visibility = "visible";
  }
};
// -----------------------------
// Loader js end
// -----------------------------

// ---------------------------------------
// Chhatbot message show/hide start
// ---------------------------------------

// $('#rd_notice_tooltip').delay(3000).fadeOut('slow');

// ---------------------------------------
// Chhatbot message show/hide end
// ---------------------------------------

// ---------------------------------------
// Searchbar function start
// ---------------------------------------

$('input#the-filter').blur(function () {
  tmpval = $(this).val();
  if (tmpval == '') {
    $('#the-list li').addClass('hide');
  }
});

window.addEventListener("load", () => {
  var filter = document.getElementById("the-filter"),
    list = document.querySelectorAll("#the-list li");
  $(list).addClass("hide");
  filter.onkeyup = () => {
    let search = filter.value.toLowerCase();
    for (let i of list) {
      let item = i.innerHTML.toLowerCase();
      if (item.indexOf(search) == -1) { i.classList.add("hide"); }
      else { i.classList.remove("hide"); }
    }
  };
});

$(document).ready(function () {
  $("#the-list li").click(function () {
    $("#the-list li").addClass("hide");
    $("#the-filter").val("");
  });
});

// /Searchbar mobile version
$('#the-filter-mob').keyup(function () {
  if ($(this).val().length == 0) {
    $('#the-list-mob').hide();
  } else {
    $('#the-list-mob').show();
  }
}).keyup();

$(document).ready(function () {
  $(".content-wrapper").click(function () {
    $("#the-list-mob").addClass("hide");
  })
})

$(document).ready(function () {
  $("#the-filter-mob").click(function () {
    $("#the-list-mob").removeClass("hide");
  })
})

$('input#the-filter-mob').blur(function () {
  tmpval = $(this).val();
  if (tmpval == '') {
    $('#the-list-mob li').addClass('hide');
  }
});

window.addEventListener("load", () => {
  var filter = document.getElementById("the-filter-mob"),
    list = document.querySelectorAll("#the-list-mob li");
  $(list).addClass("hide");
  filter.onkeyup = () => {
    let search = filter.value.toLowerCase();
    for (let i of list) {
      let item = i.innerHTML.toLowerCase();
      if (item.indexOf(search) == -1) { i.classList.add("hide"); }
      else { i.classList.remove("hide"); }
    }
  };
});

$(document).ready(function () {
  $("#the-list-mob li").click(function () {
    $("#the-list-mob li").addClass("hide");
    $("#the-filter-mob").val("");
  });
});
// ---------------------------------------
// Searchbar function end
// ---------------------------------------

// -----------------------------
// Dashboard click js start
// -----------------------------

function DashboardDiabeties() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Diabetes-abc").click();
}

function DashboardHypertension() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Hypertension-abc").click();
}

function DashboardCongestive() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Congestive-abc").click();
}

function DashboardIschemic() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Ischemic-abc").click();
}

function DashboardPulmonary() {
  document.getElementById("population-nav-item").click();
  document.getElementById("COPD-abc").click();
}

function DashboardNephrology() {
  document.getElementById("population-nav-item").click();
  document.getElementById("CKD-abc").click();
}

function DashboardOsteoporosis() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Osteoporosis-abc").click();
}

function DashboardMental() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Mental-abc").click();
}

function DashboardHearing() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Hearing-abc").click();
}

function DashboardNeonatal() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Neonatal-abc").click();
}

function DashboardPain() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Pain-abc").click();
}

function DashboardOncology() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Oncology-abc").click();
}

function DashboardSepsis() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Sepsis-abc").click();
}

function DashboardArthritis() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Arthritis-abc").click();
}

function DashboardAsthma() {
  document.getElementById("population-nav-item").click();
  document.getElementById("Asthma-abc").click();
}

function DashboardPlatform() {
  document.getElementById("connected-nav-item").click();
  document.getElementById("Integrated-abc").click();
}

function DashboardIOT() {
  document.getElementById("connected-nav-item").click();
  document.getElementById("IoT-abc").click();
}

function DashboardHealth() {
  document.getElementById("Health-abc").click();
}

function DashboardInpatient() {
  document.getElementById("intellircm-nav-item").click();
  document.getElementById("Inpatient-abc").click();
}

function DashboardRCM() {
  document.getElementById("intellircm-nav-item").click();
  document.getElementById("RCM-abc").click();
}

function DashboardAdmission() {
  document.getElementById("intellircm-nav-item").click();
  document.getElementById("Admission-abc").click();
}

function DashboardClaim() {
  document.getElementById("intellircm-nav-item").click();
  document.getElementById("Claim-abc").click();
}

function DashboardWorkforce() {
  document.getElementById("Workforce-abc").click();
}

function DashboardPharmasales() {
  document.getElementById("pharmasales-abc").click();
}

function DashboardMember() {
  document.getElementById("member-abc").click();
}

function DashboardCoverage() {
  document.getElementById("coverage-abc").click();
}

function DashboardExperience() {
  document.getElementById("experience-abc").click();
}

function DashboardEligibility() {
  document.getElementById("eligibility-abc").click();
}

function DashboardProvider() {
  document.getElementById("provider-abc").click();
}

function DashboardFraud() {
  document.getElementById("fraud-abc").click();
}

function DashboardClaims() {
  document.getElementById("claims-abc").click();
}

function DashboardRisk() {
  document.getElementById("risk-abc").click();
}

function DashboardEmployer() {
  document.getElementById("employer-abc").click();
}

function Dashboardcaremanagement() {
  document.getElementById("caremanagement-abc").click();
}

function DashboardSimulator() {
  document.getElementById("patientdetails-abc").click();
}

function DashboardRiskadjustment() {
  document.getElementById("Riskadjustment-abc").click();
}

function DashboardPatientsatisfaction() {
  document.getElementById("patientsatisfaction-abc").click();
}

function DashboardPatientdetails() {
  document.getElementById("patientdetails-abc").click();
}

function DashboardRiskscore() {
  document.getElementById("Riskscore-abc").click();
}



// -----------------------------------------------

