var botui = new BotUI("intelliai-chatbot"),
    covidModel = {},
    userModel = {};

function CallEmergency() {
    botui.message.add({
        delay: 500,
        type: "html",
        content: '<h5 style="color:#dcdcdc;padding:1em;text-align: center;">Thank You! Please visit again</h6><br/>',
        cssClass: 'thank-btn'
    }).then(function () {
        return botui.action.button({
            delay: 2e3,
            action: [{
                icon: "",
                text: "Start again",
                value: "Start again",
                cssClass: 'start-again'
            }]
        })
    }).then(function (e) {
        if (e.value === "Start again") {
            "Start again" == e.value ? LoadAssessment() : LoadAssessment();
        }
    })
}

function CreateUserModel(e, t) {
    userModel[e] = t, console.log(userModel)
}

function CreateCovidModel(e, t) {
    covidModel[e] = t, console.log(covidModel)
}

function icon(e) {
    return '<i class="botui-icon botui-message-content-icon fa fa-' + e + '"></i>'
}

function Register() {
    botui.message.bot({
        delay: 100,
        content: "We just need your Name, email and phone. All data will be kept confidential."
    }).then(function () {
        botui.action.text({
            action: {
                placeholder: "Enter your name here"
            }
        }).then(function (e) {
            CreateUserModel("Name", e.value), botui.action.text({
                action: {
                    sub_type: "email",
                    placeholder: "Enter your email here"
                }
            }).then(function (e) {
                CreateUserModel("Email", e.value), botui.action.text({
                    action: {
                        sub_type: "phone",
                        placeholder: "Enter your phone number here"
                    }
                }).then(function (e) {
                    CreateUserModel("Phone", e.value), console.log(userModel), botui.message.add({
                        delay: 1e3,
                        loading: !0,
                        type: "html"
                    }).then(function (e) {
                        botui.message.update(e, {
                            loading: !1,
                            type: "html",
                            content: "<h3>Thank you for registering with us</h3>"
                        })
                    })
                })
            })
        })
    })
}

function LoadAssessment() {
    botui.message.bot({
        delay: 100,
        content: "Hi! This is IntelliAI."
    }).then(function (e) {
        botui.message.add({
            delay: 1e3,
            human: !1,
            content: "Do you want to know about IntelliAI"
        })
    }).then(function () {
        return botui.action.button({
            delay: 2e3,
            action: [{
                icon: "",
                text: "Yes",
                value: "NO"
            },
            {
                icon: "",
                text: "No",
                value: "YES"
            }]
        })
    }).then(function (e) {
        "YES" == e.value ? CallEmergency() : Loadage()
    })
}

function Loadage() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Let's start"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please choose one"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                value: "PAYER",
                text: "IntelliPayer",
                cssClass: 'payer'
            }, {
                icon: "",
                value: "PROVIDER",
                text: "IntelliProvider",
                cssClass: 'provider'
            }, {
                icon: "",
                value: "PUBLIC",
                text: "IntelliPublic",
                cssClass: 'public'
            }, {
                icon: "",
                value: "PATIENT",
                text: "IntelliPatient",
                cssClass: 'patient'
            }, {
                icon: "",
                value: "PHARMA",
                text: "IntelliPharma",
                cssClass: 'pharma'
            }, {
                icon: "",
                text: "Quit",
                value: "QUIT",
            }]
        })
    }).then(function (e) {
        if (e.value === "PAYER") {
            "PAYER" == e.value ? IntelliPayer() : Loadage();
        }
        else if (e.value === "PROVIDER") {
            "PROVIDER" == e.value ? IntelliPayer() : Loadage();
        }
        else if (e.value === "PUBLIC") {
            "PUBLIC" == e.value ? IntelliPayer() : Loadage();
        }
        else if (e.value === "QUIT") {
            "QUIT" == e.value ? IntelliPayer() : Loadage();
        }
    })
}

function IntelliPayer() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Intelligence for Payer"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please select"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "FWA",
                value: "fwa",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Member",
                value: "Member",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Coverage",
                value: "Coverage",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Experience",
                value: "Experience",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Eligibility",
                value: "Eligibility",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Provider",
                value: "Provider",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Fraud",
                value: "Fraud",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Claims",
                value: "Claims",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Risk Stratification",
                value: "Risk Stratification",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Employer",
                value: "Employer",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? Loadage() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "Member") {
            "Member" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "fwa") {
            "fwa" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Coverage") {
            "Coverage" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Experience") {
            "Experience" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Eligibility") {
            "Eligibility" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Provider") {
            "Provider" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Fraud") {
            "Fraud" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Claims") {
            "Claims" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Risk Stratification") {
            "Risk Stratification" == e.value ? payermember() : IntelliPayer();
        }
        else if (e.value === "Employer") {
            "Employer" == e.value ? payermember() : IntelliPayer();
        }
    })
}

function payermember() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "You are choosing Intellipayer member"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please select"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "Population Analysis",
                value: "Population Analysis",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Risk Analysis",
                value: "Risk Analysis",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Evidence Based Medication",
                value: "Evidence Based Medication",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Outcome Measures",
                value: "Outcome Measures",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? IntelliPayer() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "Population Analysis") {
            "Population Analysis" == e.value ? PopulationAnalysis() : Loadage();
        }
        else if (e.value === "Risk Analysis") {
            "Risk Analysis" == e.value ? RiskAnalysis() : IntelliPayer();
        }
        else if (e.value === "Evidence Based Medication") {
            "Evidence Based Medication" == e.value ? EvidenceBasedMedication() : IntelliPayer();
        }
        else if (e.value === "Outcome Measures") {
            "Outcome Measures" == e.value ? OutcomeMeasures() : IntelliPayer();
        }
    })
}

function PopulationAnalysis() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "You are choosing population Analysis"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please select"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "Age group wise prevalence(%)",
                value: "Age group wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Rice wise prevalence(%)",
                value: "Rice wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Gender wise patients consulting per 1000",
                value: "Gender wise patient consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Age group wise patients consulting per 1000",
                value: "Age group wise patients consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? payermember() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "Age group wise prevalence") {
            "Age group wise prevalence" == e.value ? Ageprevalence() : Loadage();
        }
        else if (e.value === "Rice wise prevalence") {
            "Rice wise prevalence" == e.value ? Riceprevalence() : IntelliPayer();
        }
        else if (e.value === "Gender wise patient consulting") {
            "Gender wise patient consulting" == e.value ? Genderconsulting() : IntelliPayer();
        }
        else if (e.value === "Age group wise patients consulting") {
            "Age group wise patients consulting" == e.value ? Agegroupconsulting() : IntelliPayer();
        }
    })
}

function Ageprevalence() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Age group wise prevalence(%)"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under",
                value: "Ageprevalence",
                cssClass: 'Ageprevalence'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? PopulationAnalysis() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
    })
}

function Riceprevalence() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Rice wise prevalence(%)"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under",
                value: "Ageprevalence",
                cssClass: 'Riceprevalence'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? PopulationAnalysis() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
    })
}

function Genderconsulting() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Gender wise patients consulting per 1000"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under",
                value: "Ageprevalence",
                cssClass: 'Genderconsulting'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? PopulationAnalysis() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
    })
}

function Agegroupconsulting() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Age group wise patients consulting per 1000"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under",
                value: "Ageprevalence",
                cssClass: 'Agegroupconsulting'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? PopulationAnalysis() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
    })
}

function RiskAnalysis() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "You are choosing population Analysis"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please select"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "Age group wise prevalence(%)",
                value: "Age group wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Rice wise prevalence(%)",
                value: "Rice wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Gender wise patients consulting per 1000",
                value: "Gender wise patient consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Age group wise patients consulting per 1000",
                value: "Age group wise patients consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? payermember() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "Age group wise prevalence") {
            "Age group wise prevalence" == e.value ? Ageprevalence() : Loadage();
        }
        else if (e.value === "Rice wise prevalence") {
            "Rice wise prevalence" == e.value ? Riceprevalence() : IntelliPayer();
        }
        else if (e.value === "Gender wise patient consulting") {
            "Gender wise patient consulting" == e.value ? Genderconsulting() : IntelliPayer();
        }
        else if (e.value === "Age group wise patients consulting") {
            "Age group wise patients consulting" == e.value ? Agegroupconsulting() : IntelliPayer();
        }
    })
}

function EvidenceBasedMedication() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "You are choosing population Analysis"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please select"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "Age group wise prevalence(%)",
                value: "Age group wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Rice wise prevalence(%)",
                value: "Rice wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Gender wise patients consulting per 1000",
                value: "Gender wise patient consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Age group wise patients consulting per 1000",
                value: "Age group wise patients consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? payermember() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "Age group wise prevalence") {
            "Age group wise prevalence" == e.value ? Ageprevalence() : Loadage();
        }
        else if (e.value === "Rice wise prevalence") {
            "Rice wise prevalence" == e.value ? Riceprevalence() : IntelliPayer();
        }
        else if (e.value === "Gender wise patient consulting") {
            "Gender wise patient consulting" == e.value ? Genderconsulting() : IntelliPayer();
        }
        else if (e.value === "Age group wise patients consulting") {
            "Age group wise patients consulting" == e.value ? Agegroupconsulting() : IntelliPayer();
        }
    })
}

function OutcomeMeasures() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "You are choosing population Analysis"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please select"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "Age group wise prevalence(%)",
                value: "Age group wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Rice wise prevalence(%)",
                value: "Rice wise prevalence",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Gender wise patients consulting per 1000",
                value: "Gender wise patient consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Age group wise patients consulting per 1000",
                value: "Age group wise patients consulting",
                cssClass: 'half-button'
            }, {
                icon: "",
                text: "Back",
                value: "Back",
                cssClass: 'half-button back'
            }, {
                icon: "",
                text: "Quit",
                value: "Quit",
                cssClass: 'half-button quit'
            }]
        })
    }).then(function (e) {
        if (e.value === "Back") {
            "Back" == e.value ? payermember() : Loadage();
        }
        else if (e.value === "Quit") {
            "Quit" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "Age group wise prevalence") {
            "Age group wise prevalence" == e.value ? Ageprevalence() : Loadage();
        }
        else if (e.value === "Rice wise prevalence") {
            "Rice wise prevalence" == e.value ? Riceprevalence() : IntelliPayer();
        }
        else if (e.value === "Gender wise patient consulting") {
            "Gender wise patient consulting" == e.value ? Genderconsulting() : IntelliPayer();
        }
        else if (e.value === "Age group wise patients consulting") {
            "Age group wise patients consulting" == e.value ? Agegroupconsulting() : IntelliPayer();
        }
    })
}

function IntelliProvider() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Age group wise prevelance (%) provider"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please choose one"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under",
                value: "fever, chills, or sweating"
            }, {
                icon: "",
                text: "5 - 14 years",
                value: "Difficulty breathing (not servere)"
            }, {
                icon: "",
                text: "15 - 24 Years",
                value: "New or worsening cough"
            }, {
                icon: "",
                text: "25 - 34 Years",
                value: "Sore throat"
            }, {
                icon: "",
                text: "35 - 44 Years",
                value: "Aching throughout the body"
            }, {
                icon: "",
                text: "45 - 54 Years",
                value: "Vomiting or diarrhea"
            }, {
                icon: "",
                text: "65 - 74 Years",
                value: "None of the above"
            }, {
                icon: "",
                text: "74 Years and over",
                value: "None of the above"
            }]
        })
    }).then(function (e) {
        botui.message.add({
            delay: 500,
            human: !1,
            content: "Here is your result"
        })
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under - 29%",
                value: "Asthma or chronic lung disease"
            }, {
                icon: "",
                text: "5 - 14 years - 28%",
                value: "Pregnancy"
            }, {
                icon: "",
                text: "15 - 24 Years - 28.6%",
                value: "Diabetes with complications"
            }, {
                icon: "",
                text: "25 - 34 Years - 30%",
                value: "Diseases or conditions that make it harder to cough"
            }, {
                icon: "",
                text: "35 - 44 Years - 27%",
                value: "Kidney failure that needs dialysis"
            }, {
                icon: "",
                text: "45 - 54 Years - 29.9%",
                value: "Cirrhosis of the liver"
            }, {
                icon: "",
                text: "65 - 74 Years - 29.8%",
                value: "Weakened immune system"
            }, {
                icon: "",
                text: "74 Years and over - 28.8%",
                value: "Congestive heart failure"
            }, {
                icon: "",
                text: "Return To IntelliPayer Menu",
                value: "PAYERRETURN"
            }, {
                icon: "",
                text: "Return To Main Menu",
                value: "RETURN"
            }, {
                icon: "",
                text: "Quit",
                value: "QUIT"
            }]
        })
    }).then(function (e) {
        if (e.value === "QUIT") {
            "QUIT" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "RETURN") {
            "RETURN" == e.value ? Loadage() : Loadage();
        }
        else if (e.value === "PAYERRETURN") {
            "PAYERRETURN" == e.value ? IntelliPayer() : IntelliPayer();
        }
    })
}

function IntelliPublic() {
    botui.message.add({
        delay: 500,
        human: !1,
        content: "Age group wise prevelance (%) public"
    }), botui.message.add({
        delay: 1500,
        human: !1,
        content: "Please choose one"
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under",
                value: "fever, chills, or sweating"
            }, {
                icon: "",
                text: "5 - 14 years",
                value: "Difficulty breathing (not servere)"
            }, {
                icon: "",
                text: "15 - 24 Years",
                value: "New or worsening cough"
            }, {
                icon: "",
                text: "25 - 34 Years",
                value: "Sore throat"
            }, {
                icon: "",
                text: "35 - 44 Years",
                value: "Aching throughout the body"
            }, {
                icon: "",
                text: "45 - 54 Years",
                value: "Vomiting or diarrhea"
            }, {
                icon: "",
                text: "65 - 74 Years",
                value: "None of the above"
            }, {
                icon: "",
                text: "74 Years and over",
                value: "None of the above"
            }]
        })
    }).then(function (e) {
        botui.message.add({
            delay: 500,
            human: !1,
            content: "Here is your result"
        })
    }).then(function () {
        return botui.action.button({
            delay: 1e3,
            action: [{
                icon: "",
                text: "4 Yreas and Under - 29%",
                value: "Asthma or chronic lung disease"
            }, {
                icon: "",
                text: "5 - 14 years - 28%",
                value: "Pregnancy"
            }, {
                icon: "",
                text: "15 - 24 Years - 28.6%",
                value: "Diabetes with complications"
            }, {
                icon: "",
                text: "25 - 34 Years - 30%",
                value: "Diseases or conditions that make it harder to cough"
            }, {
                icon: "",
                text: "35 - 44 Years - 27%",
                value: "Kidney failure that needs dialysis"
            }, {
                icon: "",
                text: "45 - 54 Years - 29.9%",
                value: "Cirrhosis of the liver"
            }, {
                icon: "",
                text: "65 - 74 Years - 29.8%",
                value: "Weakened immune system"
            }, {
                icon: "",
                text: "74 Years and over - 28.8%",
                value: "Congestive heart failure"
            }, {
                icon: "",
                text: "Return To IntelliPayer Menu",
                value: "PAYERRETURN"
            }, {
                icon: "",
                text: "Return To Main Menu",
                value: "RETURN"
            }, {
                icon: "",
                text: "Quit",
                value: "QUIT"
            }]
        })
    }).then(function (e) {
        if (e.value === "QUIT") {
            "QUIT" == e.value ? CallEmergency() : Loadage();
        }
        else if (e.value === "RETURN") {
            "RETURN" == e.value ? Loadage() : Loadage();
        }
        else if (e.value === "PAYERRETURN") {
            "PAYERRETURN" == e.value ? IntelliPayer() : IntelliPayer();
        }
    })
}
// return botui.message.add({
//     type: "html",
//     delay: 1e3,
//     content: message
// });

// .then(function (e) {
//     "RETURN" == e.value ? Loadage() : Loadage();
//     "QUIT" == e.value ? CallEmergency() : Loadage();
//     "PAYERRETURN" == e.value ? IntelliPayer() : IntelliPayer();
// })

// function ContinueAssessment() {
//     botui.message.add({
//         delay: 500,
//         human: !1,
//         content: "Let's start"
//     }), botui.message.add({
//         delay: 1500,
//         human: !1,
//         content: "Please choose one"
//     }).then(function() {
//         return botui.action.button({
//             delay: 1e3,
//             action: [{
//                 icon: "",
//                 text: "IntelliPayer",
//                 value: "18"
//             }, {
//                 icon: "",
//                 text: "Intelliprovider",
//                 value: "18-64"
//             }, {
//                 icon: "",
//                 text: "Intellipublic",
//                 value: "65"
//             }]
//         })
//     }).then(function(e) {
//         CreateCovidModel("Age", e.value)
//     }).then(function(e) {
//         botui.message.add({
//             delay: 500,
//             human: !1,
//             content: "Select your Query?"
//         })
//     }).then(function() {
//         return botui.action.button({
//             delay: 1e3,
//             action: [{
//                 icon: "",
//                 text: "Member",
//                 value: "MEMBER"
//             }, {
//                 icon: "",
//                 text: "Coverage",
//                 value: "COVERAGE"
//             }, {
//                 icon: "",
//                 text: "Experiance",
//                 value: "Experience"
//             }, {
//                 icon: "",
//                 text: "Return To Main Menu",
//                 value: "return"
//             }]
//         })
//     }).then(function(e) {
//         "return" == e.value ? CallEmergency() : ContinueAssessment()
//     }).then(function(e) {
//         CreateCovidModel("Gender", e.value)
//     }).then(function(e) {
//         botui.message.add({
//             delay: 500,
//             human: !1,
//             content: "Age group wise prevelance (%)"
//         })
//     }).then(function() {
//         return botui.action.button({
//             delay: 1e3,
//             action: [{
//                 icon: "",
//                 text: "4 Yreas and Under",
//                 value: "fever, chills, or sweating"
//             }, {
//                 icon: "",
//                 text: "5-14 years",
//                 value: "Difficulty breathing (not servere)"
//             }, {
//                 icon: "",
//                 text: "15-24 Years",
//                 value: "New or worsening cough"
//             }, {
//                 icon: "",
//                 text: "25-34 Years",
//                 value: "Sore throat"
//             }, {
//                 icon: "",
//                 text: "35-44 Years",
//                 value: "Aching throughout the body"
//             }, {
//                 icon: "",
//                 text: "45-54 Years",
//                 value: "Vomiting or diarrhea"
//             }, {
//                 icon: "",
//                 text: "65-74 Years",
//                 value: "None of the above"
//             }, {
//                 icon: "",
//                 text: "74 Years and over",
//                 value: "None of the above"
//             }, {
//                 icon: "",
//                 text: "Return To IntelliPayer Menu",
//                 value: "payerreturn"
//             }, {
//                 icon: "",
//                 text: "Return To Main Menu",
//                 value: "return"
//             }]
//         })
//     }).then(function(e) {
//         botui.message.add({
//             delay: 500,
//             human: !1,
//             content: "Here is your result"
//         })
//     }).then(function() {
//         return botui.action.button({
//             delay: 1e3,
//             action: [{
//                 icon: "",
//                 text: "4 Yreas and Under - 29%",
//                 value: "Asthma or chronic lung disease"
//             }, {
//                 icon: "",
//                 text: "5-14 years - 28%",
//                 value: "Pregnancy"
//             }, {
//                 icon: "",
//                 text: "15-24 Years - 28.6%",
//                 value: "Diabetes with complications"
//             }, {
//                 icon: "",
//                 text: "25-34 Years - 30%",
//                 value: "Diseases or conditions that make it harder to cough"
//             }, {
//                 icon: "",
//                 text: "35-44 Years - 27%",
//                 value: "Kidney failure that needs dialysis"
//             }, {
//                 icon: "",
//                 text: "45-54 Years - 29.9%",
//                 value: "Cirrhosis of the liver"
//             }, {
//                 icon: "",
//                 text: "65-74 Years - 29.8%",
//                 value: "Weakened immune system"
//             }, {
//                 icon: "",
//                 text: "74 Years and over - 28.8%",
//                 value: "Congestive heart failure"
//             }, {
//                 icon: "",
//                 text: "Return To IntelliPayer Menu",
//                 value: "payerreturn"
//             }, {
//                 icon: "",
//                 text: "Return To Main Menu",
//                 value: "return"
//             }, {
//                 icon: "",
//                 text: "Quit",
//                 value: "QUIT"
//             }]
//         })
//     }).then(function(e) {
//         "QUIT" == e.value ? CallEmergency() : ContinueAssessment()
//     }).then(function(e) {
//         "return" == e.value ? CallEmergency() : ContinueAssessment()
//     }).then(function(e) {
//         "payerreturn" == e.value ? CallEmergency() : ContinueAssessment()
//     })
// }
LoadAssessment();